<?php

require_once "Conexao.php";


class Comentario
{

    public $dt_avaliacao;
    public $avaliacao;



    public function __construct($dt_avaliacao, $avaliacao)
    {

        $this->dt_avaliacao = $dt_avaliacao;
        $this->avaliacao = $avaliacao;
        $this->lugar_idlugar = null;


    }

}