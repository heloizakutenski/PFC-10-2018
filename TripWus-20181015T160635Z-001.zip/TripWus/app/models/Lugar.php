<?php
require_once "Conexao.php";

class Lugar
{
    public $id_end;

    /**
     * @return null
     */
    public function getIdEnd()
    {
        return $this->id_end;
    }

    /**
     * @param null $id_end
     */
    public function setIdEnd($id_end): void
    {
        $this->id_end = $id_end;
    }

    /**
     * @return null
     */
    public function getNomeL()
    {
        return $this->nome_l;
    }

    /**
     * @param null $nome_l
     */
    public function setNomeL($nome_l): void
    {
        $this->nome_l = $nome_l;
    }

    /**
     * @return null
     */
    public function getTel()
    {
        return $this->tel;
    }

    /**
     * @param null $tel
     */
    public function setTel($tel): void
    {
        $this->tel = $tel;
    }

    /**
     * @return null
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param null $email
     */
    public function setEmail($email): void
    {
        $this->email = $email;
    }

    /**
     * @return null
     */
    public function getHrAt()
    {
        return $this->hr_at;
    }

    /**
     * @param null $hr_at
     */
    public function setHrAt($hr_at): void
    {
        $this->hr_at = $hr_at;
    }

    /**
     * @return null
     */
    public function getHrAtAte()
    {
        return $this->hr_at_ate;
    }

    /**
     * @param null $hr_at_ate
     */
    public function setHrAtAte($hr_at_ate): void
    {
        $this->hr_at_ate = $hr_at_ate;
    }

    /**
     * @return null
     */
    public function getIdadeMin()
    {
        return $this->idade_min;
    }

    /**
     * @param null $idade_min
     */
    public function setIdadeMin($idade_min): void
    {
        $this->idade_min = $idade_min;
    }

    /**
     * @return null
     */
    public function getAccAnimal()
    {
        return $this->acc_animal;
    }

    /**
     * @param null $acc_animal
     */
    public function setAccAnimal($acc_animal): void
    {
        $this->acc_animal = $acc_animal;
    }

    /**
     * @return null
     */
    public function getEstrelas()
    {
        return $this->estrelas;
    }

    /**
     * @param null $estrelas
     */
    public function setEstrelas($estrelas): void
    {
        $this->estrelas = $estrelas;
    }

    /**
     * @return null
     */
    public function getDiaAt()
    {
        return $this->dia_at;
    }

    /**
     * @param null $dia_at
     */
    public function setDiaAt($dia_at): void
    {
        $this->dia_at = $dia_at;
    }

    /**
     * @return null
     */
    public function getDiaAtAte()
    {
        return $this->dia_at_ate;
    }

    /**
     * @param null $dia_at_ate
     */
    public function setDiaAtAte($dia_at_ate): void
    {
        $this->dia_at_ate = $dia_at_ate;
    }

    /**
     * @return null
     */
    public function getTipoLugar()
    {
        return $this->tipo_lugar;
    }

    /**
     * @param null $tipo_lugar
     */
    public function setTipoLugar($tipo_lugar): void
    {
        $this->tipo_lugar = $tipo_lugar;
    }

    /**
     * @return null
     */
    public function getIdFoto()
    {
        return $this->id_foto;
    }

    /**
     * @param null $id_foto
     */
    public function setIdFoto($id_foto): void
    {
        $this->id_foto = $id_foto;
    }
    public $continente;
    public $nome_l;
    public $tel;
    public $email;
    public $hr_at;
    public $hr_at_ate;
    public $idade_min;
    public $acc_animal;
    public $estrelas;
    public $dia_at;
    public $dia_at_ate;
    public $tipo_lugar;
    public $id_foto;







    //Crie um usuario
    public function __construct($continente = null,
                                $nome_l     = null,
                                $tel        = null,
                                $email      = null,
                                $hr_at      = null,
                                $hr_at_ate  = null,
                                $idade_min  = null,
                                $acc_animal = null,
                                $estrelas   = null,
                                $dia_at     = null,
                                $dia_at_ate = null,
                                $tipo_lugar = null,
                                $id_end     = null,
                                $id_foto    = null)
    {
        $this->continente = $continente;
        $this->nome_l = $nome_l;
        $this->tel = $tel;
        $this->email = $email;
        $this->hr_at = $hr_at;
        $this->hr_at_ate = $hr_at_ate;
        $this->idade_min = $idade_min;
        $this->acc_animal = $acc_animal;
        $this->estrelas = $estrelas;
        $this->dia_at = $dia_at;
        $this->dia_at_ate = $dia_at_ate;
        $this->tipo_lugar = $tipo_lugar;
        $this->id_end = $id_end;
        $this->id_foto = $id_foto;


    }


}