<?php
/**
 * Created by PhpStorm.
 * User: ThiagoWalter
 * Date: 14/06/2018
 * Time: 14:17
 */

class CrudFotos
{

    private $conexao;


    public function __construct()
    {
        $this->conexao = Conexao::getConexao();
    }

    public function novaFoto(Fotos $fotos)
    {
        //Após receber o usuario novo, realize a conexão e insira no banco estes dados
        $sql = "INSERT INTO fotos ( midia) VALUES ('$fotos->midia')";
            echo $sql;
        $this->conexao->exec($sql);
        return($this->conexao->lastInsertId());

    }
    public function getFoto($id_foto){
        $sql = ("SELECT * FROM fotos WHERE idfotos = $id_foto");
        echo $sql;
        $this->conexao->exec($sql);
    }



}