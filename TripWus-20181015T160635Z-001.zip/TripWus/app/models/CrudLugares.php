<?php

require_once "Conexao.php";
require_once "Lugar.php";
require_once "CrudFotos.php";
class CrudLugares
{
    private $conexao;


    public function __construct()
    {
        $this->conexao = Conexao::getConexao();
    }

    public function NovoLugar(Lugar $lugar)
    {
        //Após receber o usuario novo, realize a conexão e insira no banco estes dados
        $this->conexao->exec("INSERT INTO lugar (continente, nome, telefone, email, hr_at_das, hr_at_ate, idade_minima,
        aceita_animais, estrelas, dia_at_de, dia_at_a, tipo_lugar_idtipo_lugar, endereco_idendereco, fotos_idfotos) 
        VALUES ('$lugar->continente','$lugar->nome_l', '$lugar->tel', '$lugar->email', '$lugar->hr_at', '$lugar->hr_at_ate', '$lugar->idade_min', '$lugar->acc_animal', '$lugar->estrelas', '$lugar->dia_at','$lugar->dia_at_ate', '$lugar->tipo_lugar' , '$lugar->id_end', '$lugar->id_foto')");
    }

    public function getLugares()
    {
        $consulta = $this->conexao->query("SELECT * FROM lugar");
        $listaArray = $consulta->fetchAll(PDO::FETCH_ASSOC);
        $listaObjetos = [];
        foreach ($listaArray as $lugarLista) {
            #append lista em php
            $lugar = new Lugar($lugarLista['continente'],
                                        $lugarLista['nome'],
                                        $lugarLista['telefone'],
                                        $lugarLista['email'],
                                        $lugarLista['hr_at_das'],
                                        $lugarLista['hr_at_ate'],
                                        $lugarLista['idade_min'],
                                        $lugarLista['acc_animal'],
                                        $lugarLista['estrelas'],
                                        $lugarLista['dia_at_de'],
                                        $lugarLista['dia_at_a'],
                                        $lugarLista['tipo_lugar_idtipo_lugar'],
                                        $lugarLista['id_end'],
                                        $lugarLista['fotos_idfotos']);
            array_push($listaObjetos, $lugar);
        }
        return $listaObjetos;
    }

}
