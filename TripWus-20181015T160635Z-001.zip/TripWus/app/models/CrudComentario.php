<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 10/08/2018
 * Time: 13:50
 */


class CrudComentario
{
    private $conexao;


    public function __construct()
    {
        $this->conexao = Conexao::getConexao();
    }

    public function comenta(Comentario $comenta)
    {
        //Após receber o usuario novo, realize a conexão e insira no banco estes dados
        $this->conexao->exec("INSERT INTO avaliacao (dt_avaliacao, avaliacao, lugar_idlugar) 
        VALUES (
        '$comenta->dt_avaliacao', '$comenta->avaliacao', 6");


    }



}