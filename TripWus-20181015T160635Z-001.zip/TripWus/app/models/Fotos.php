<?php

require_once "Conexao.php";

/**
 * Created by PhpStorm.
 * User: ThiagoWalter
 * Date: 14/06/2018
 * Time: 14:10
 */

class Fotos
{
    public $id_fotos;
    public $midia;



    public function __construct($midia)
    {
        $this->midia = $midia;
    }

}