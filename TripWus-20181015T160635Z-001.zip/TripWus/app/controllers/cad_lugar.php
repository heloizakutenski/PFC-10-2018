<?php

    require_once "../models/Conexao.php";
    require_once "../models/Lugar.php";
    require_once "../models/Endereco.php";
    require_once "../models/CrudLugares.php";
    require_once "../models/CrudEndereco.php";
    require_once "../models/Fotos.php";

    require_once "../models/CrudFotos.php";



if ($_POST) {
    $tipo_lugar = $_POST['tipo'];
    $cep = $_POST['cep'];
    $pais = $_POST['pais'];
    $uf = $_POST['uf'];
    $continente = $_POST['continente'];
    $cidade = $_POST['cidade'];
    $bairro = $_POST['bairro'];
    $nome_rua = $_POST['rua'];
    $numero = $_POST['numero_rua'];
    $nome_l = $_POST['nome_l'];
    $tel = $_POST['numero'];
    $email = $_POST['email'];
    $hr_at = $_POST['hora_d'];
    $hr_at_ate = $_POST['hora_a'];
    $idade_min = $_POST['idade'];
    $acc_animal = $_POST['animal'];
    $estrelas = $_POST['estrelas'];
    $dia_at = $_POST['De_sem'];
    $dia_at_ate = $_POST['A_sem'];



    print_r($_POST);


    $tip_arqv = array('jpeg', 'jpg', 'png');
    $tm_arqv = 1024 * 20000 ;

    if (!empty($_FILES['midia']['name'])){
        $arqvTm = $_FILES['midia']['size'];
        $arqvType = pathinfo($_FILES['midia']['name'] , PATHINFO_EXTENSION);
        $arqvError = $_FILES['midia']['error'];
        $nomeArq = date('dmyHiss').$_FILES['midia']['name'];
        $arqTemp = $_FILES['midia']['tmp_name'];
        if (array_search($arqvType, $tip_arqv) == false){ // testa se o formato eh aceito
            header("Location");
            //VERIFICAR PARA ONDE ENVIAR!!
        }
        $pasta = "../../assets/img/";
        if(!file_exists($pasta)){
            mkdir("../../assets/img/");
        }
        $upload = move_uploaded_file($arqTemp, $pasta . $nomeArq);
    }



        $new_endereco = new Endereco($cep, $pais, $uf, $cidade, $bairro, $nome_rua, $numero);
        $cria = new CrudEndereco();
        $id_endereco = $cria->inserir($new_endereco);

        $new_foto = new Fotos($nomeArq);
        $coloca = new CrudFotos();
        $id_fotos = $coloca->novaFoto($new_foto);
        //VER NO BD, CRIAR AUTO_INCREMENTO NA PK

        $new_lugar = new Lugar($continente, $nome_l, $tel, $email, $hr_at, $hr_at_ate, $idade_min, $acc_animal, $estrelas, $dia_at, $dia_at_ate, $tipo_lugar, $id_endereco, $id_fotos);
        $crud = new CrudLugares();
        $crud->NovoLugar($new_lugar);


//  header("Location: ../views/index.php");
}
