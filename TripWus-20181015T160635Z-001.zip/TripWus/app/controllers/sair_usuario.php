<?php

require_once "../models/Login.php";

    $login = new Login();
    $login->sair();
?>