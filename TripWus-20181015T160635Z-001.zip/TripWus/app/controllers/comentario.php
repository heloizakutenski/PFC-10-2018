<?php

require_once "../models/Comentario.php";
require_once "../models/CrudComentario.php";

if($_POST){

    $dt_avaliacao = date('dmyHiss');
    $comentario = $_POST['comentario'];

    $new_comentario = new Comentario($dt_avaliacao, $comentario);
    $crud = new CrudComentario();
    $crud->comenta($new_comentario);


}

