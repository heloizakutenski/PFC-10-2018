<!DOCTYPE html>
<html lang="pt">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>TripWus</title>

    <!--
     Links do site inteiro

    Com ele os site funciona, pois ao lincar tudo, ele chamaas funçoes necessarias para executar determinadas funçoes
    -->

    <link rel="shortcut icon" type="img/x-png" href="../../assets/img/logo-top.png">
    <link rel="stylesheet" type="text/css" href="../../assets/vendor/semantic/semantic.css">
    <link rel="stylesheet" type="text/css" href="../../assets/css/estilo.css">
    <script type="text/javascript" src="../../assets/vendor/jquery/jquery.js"></script>
    <script type="text/javascript" src="../../assets/vendor/semantic/semantic.js"></script>
    <script type="text/javascript" src="../../assets/vendor/semantic/semantic.min.js"></script>
    <script type="text/javascript" src="../../assets/js/script.js"></script>


</head>

<body>


<!--Barra do topo la em cima

a pagina que vai ser incluida (include)

-->

<?php include ("adm/topo.php")?>

<!-- Avião -->

<header id="Avi">
    <div class="ui stackable grid">
        <div id="texto" class="ui sizer vertical segment superior">

            <img class="imagem" src="../../assets/img/avi.jpg">
            <section class="sobrepor">
                <div class="ui header titulo">
                    <h1 class="textosup">O melhor para sua viagem</h1>

                    <div class="ui divider"></div>

                    <p class="textoinf">Milhares de destinos e avaliações em um só lugar</p>

                    <?php
                    if(isset($_SESSION['nome'])) {
                        echo ('');
                    }
                    else{
                        echo('<button class="big ui button">
                        <a href="cadastro.php">
                            <p class="corp textob">Junte-se a nós</p>
                        </a>
                    </button>');
                    }

                    ?>
                </div>
            </section>
        </div>
    </div>
</header>


<!-- Menu -->

<section id="Menu">
    <div class="ui menu">
        <div class="ui stackable equal width sem_margem grid">
            <div class="column emcima">
                <img src="../../assets/img/1.jpg" class="ui posicao image embaixo">
                <div class="item sobreposto">
                    <a href="america.php">
                        <p>AMÉRICA</p>
                    </a>
                </div>
            </div>
            <div class="column emcima">
                <img src="../../assets/img/2.jpg" class="ui image">
                <div class="item sobreposto">
                    <a href="europa.php">
                        <p>EUROPA</p>
                    </a>
                </div>
            </div>
            <div class="column emcima">
                <img src="../../assets/img/3.jpg" class="ui posicao image">
                <div class="item sobreposto">
                    <a href="asia.php">
                        <p>ÁSIA</p>
                    </a>
                </div>
            </div>
            <div class="equal width row">
                <div class="column emcima">
                    <img src="../../assets/img/4.jpg" class="ui image">
                    <div class="item sobreposto">
                        <a href="africa.php">
                            <p>ÁFRICA</p>
                        </a>
                    </div>
                </div>
                <div class="column emcima">
                    <img src="../../assets/img/5.jpg" class="ui image">
                    <div class="item sobreposto">
                        <a href="oceania.php">
                            <p>OCEANIA</p>
                        </a>
                    </div>
                </div>
                <div class="column emcima">
                    <img src="../../assets/img/6.jpg" class="ui image">
                    <div class="item sobreposto">
                        <a href="antartida.php">
                            <p>ANTÁRTIDA</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>

<?php include ("adm/rodape.php")?>

</body>

</html>



