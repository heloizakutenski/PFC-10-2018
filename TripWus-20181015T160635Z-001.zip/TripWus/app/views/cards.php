<?php include ("adm/topo.php")?>
<?
include_once __DIR__."../models/CrudLugares.php";
$crudLugares = new CrudLugares();
$lugares     = $crudLugares->getLugares();

foreach ($lugares as $lugar);
?>


    <section>
        <div id="Principal">
            <img class="imagem" src="../../assets/img/card.jpg">

            <div class="sobrepor alinharPerfil">

                <div class="ui stackable grid opaco">
                    <div class="four wide column"></div>
                        <div class="eight wide column">
                            <div id="card" class="ui segment">
                                <h2><?=$lugar->getNomeL();?></h2>
                            </div>
                        </div>
                    <div class="four wide column"></div>
                </div>
            </div>
        </div>
    </section>




<?php include ("adm/rodape.php")?>