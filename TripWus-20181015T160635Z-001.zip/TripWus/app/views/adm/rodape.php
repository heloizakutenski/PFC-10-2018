<section id="Rodape" class="ui section">
    <div class="ui container">

        <section class="ui corb section">

            <h2>Dúvidas, Reclamações ou Sugestões</h2>
            <div class="ui divider"></div>
            <p>Para uma experiência de maior qualiade, reporte-nos qualquer problema, duvida ou sugestão</p>

            <p>
                <a class="corb" href="https://goo.gl/CfvNFW">contato.tw@tripwus.com</a>
            </p>

            <i class="huge mail icon"></i>
        </section>

    </div>
</section>