<link rel="shortcut icon" type="img/x-png" href="../../assets/img/logo-top.png">
<link rel="stylesheet" type="text/css" href="../../assets/vendor/semantic/semantic.css">
<link rel="stylesheet" type="text/css" href="../../assets/css/estilo.css">
<script type="text/javascript" src="../../assets/vendor/jquery/jquery.js"></script>
<script type="text/javascript" src="../../assets/vendor/semantic/semantic.js"></script>
<script type="text/javascript" src="../../assets/vendor/semantic/semantic.min.js"></script>
<script type="text/javascript" src="../../assets/js/script.js"></script>



<nav id="Topo">
    <div class="espaco">
        <div class="ui secondary pointing big menu">

            <div id="Logo" class="ui-text topo">

                <a href="index.php">
                    <img src="../../assets/img/logo.png">
                </a>


            </div>

            <div class="right menu corb">
                <?php
                session_start();
                if(isset($_SESSION['nome'])) {

                    echo ('
                    
                     <a id="cad" style="color: white; margin-bottom:1%" class="ui item" href="cad_local.php">
                        <i id="mapa" class="map icon"></i>
                             
                    </a>     
                    <div id="user" class="ui pointing dropdown link item" style="color: white">
                        <i class="ui right large user icon"></i>
                        <div class="menu">
                           <a class="ui item" href="perfil.php">
                           <i class="user icon"></i>
                              Perfil
                           </a>
                                                    
                              <div class="ui divider"></div>
                           <a class="ui item" href="../controllers/sair_usuario.php">
                           <i class="sign out icon"></i>                             
                              Sair
                           </a>
                        </div>
                    </div> 
                    <br>
                    <label for="user">
                        <h6>Cadastro de Local</h6>
                        
                    </label>
                    <p>Bem vindo ' . $_SESSION["nome"] .'</p>');

                }

                else{
                    echo('
                <a class="ui item" href="cadastro.php">
                    <p class="corb">Cadastrar</p>
                </a>
                <a class="ui item" href="login.php">
                    <p class="corb">Entrar</p>
                </a>
                ');
                }

                ?>
            </div>
        </div>
    </div>
</nav>