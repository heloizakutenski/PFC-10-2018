<?php
include_once __DIR__."/../../models/CrudLugares.php";
$crudLugares = new CrudLugares();
$lugares     = $crudLugares->getLugares();



foreach ($lugares as $lugar)?>
<div class="ui divider clica"></div>
    <div class="alinhamentoC">
        <div class="ui special cards">
            <div class="card">
                <div class="blurring dimmable image">
                    <div class="ui dimmer">
                        <div class="content">
                            <div class="center">
                                <div class="ui inverted button">
                                    <a class="link" href="cards.php">
                                        <p class="link" >Veja +</p>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <img src="../../assets/img/chu.jpg">
                </div>
                <div class="content">
                    <p class="header"><?=$lugar->getNomeL();?></p>
                    <div class="meta">
                        <i class="star icon"></i><span><?=$lugar->getEstrelas();?></span>
                    </div>
                </div>
                <div class="extra content">
                    <div class="ui large transparent  icon input">

                            <form method="post" action="../controllers/comentario.php">
                                <input name="comentario" type="text" placeholder="Comentário">
                                <button style="float: left" class="ui alinhamentoBt tiny button">Enviar</button>
                            </form>

                    </div>
                </div>
            </div>
        </div>
    </div>


