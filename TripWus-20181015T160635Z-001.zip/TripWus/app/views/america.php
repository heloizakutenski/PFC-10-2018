<!DOCTYPE html>
<html lang="pt">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>TripWus</title>

    <!-- Css do site inteiro-->
    <link rel="shortcut icon" type="img/x-png" href="../../assets/img/logo-top.png">
    <link rel="stylesheet" type="text/css" href="../../assets/vendor/semantic/semantic.css">
    <link rel="stylesheet" type="text/css" href="../../assets/css/estilo.css">
    <link rel="stylesheet" type="text/js" href="../../assets/js/script.js">


</head>

<body>


<!--Barra do topo la em cima -->

<?php include ("adm/topo.php")?>

<section id="paises">

    <div>
        <img class="imagem" src="../../assets/img/america.jpg">
    </div>





    <br>
    <br>
    <br>
    <div class="ui divider"></div>
    <br>
    <br>
    <br>
    <div class="caixa">


        <div class="ui stackable grid">
            <div class="ui column"></div>
            <div class="ui fourteen wide column">
                <div class="ui three columns grid stackable">
                    <div class="ui column">
                        <section class="ui segment yellow">
                            <h3 class="header textoalin">Gastronomia</h3>
                            <?php include ("adm/segments.php")?>
                        </section>
                    </div>
                    <div class="ui column">
                        <section class="ui segment blue">
                            <h3 class="header textoalin">Hotelaria</h3>
                            <?php include ("adm/segments.php")?>
                        </section>
                    </div>
                    <div class="ui column">
                        <section class="ui segment orange">
                            <h3 class="header textoalin">Pontos turísticos</h3>
                            <?php include ("adm/segments.php")?>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </div>


</section>


<?php include ("adm/rodape.php")?>


</body>

</html>